# layui-node
学习node编程的写的第一个项目。
基于前端框架layui，使用node搭建的一套简单的后台管理。关于即时通讯的功能我移除掉了，还没有做好并且layim也不是开源 :blush: 